<?php
//2210631170074 - Ilham Arif Farabi
$db = mysqli_connect("localhost", "root", "", "perpustakaan_saya") or die("gagal konek");
