<?php
$nama_mahasiswa = "Ariel Tatum" ;
$nama_kamu = "Andi" ;

if ($nama_mahasiswa == "Ariel Tatum") {
$jenis_kelamin = " Perempuan"; 
} else if ($nama_kamu == "Andi") {
$jenis_kelamin = "Laki - laki";
} else $jenis_kelamin = "??";

echo "Hallo ".$nama_mahasiswa. " Selamat datang, <br>saya ".$nama_kamu. "
jenis kelamin kamu adalah ".$jenis_kelamin;

?>

<html>
<br>
Calon pacar saya...
<html>
