<?php
include "koneksi.php";

    $get_data = mysqli_query($koneksi, "SELECT * FROM mahasiswa");