<?php

    $var1 = $_GET['inputan_nama'];
    echo $var1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="GET">
        Nama : 
        <input type="text" name="inputan_nama">
        <button type="submit">Proses</button> 
    </form>
</body>
</html>