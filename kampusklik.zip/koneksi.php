<?php

$koneksi = mysqli_connect("localhost", "root", "", "kuliah_pemrograman_web");
// if ($koneksi) {
//     echo "berhasil konek";
// } else {
//     echo "gagal konek";
// }